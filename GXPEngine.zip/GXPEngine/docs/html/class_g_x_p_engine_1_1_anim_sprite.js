var class_g_x_p_engine_1_1_anim_sprite =
[
    [ "AnimSprite", "class_g_x_p_engine_1_1_anim_sprite.html#aaedfb5eb0d6d92dfb66db647a310129e", null ],
    [ "AnimSprite", "class_g_x_p_engine_1_1_anim_sprite.html#a04f3fd34b4ee71df5e34f4323da2ed8b", null ],
    [ "NextFrame", "class_g_x_p_engine_1_1_anim_sprite.html#a2fde6b961a4ee03e297e69b0a1862c71", null ],
    [ "SetFrame", "class_g_x_p_engine_1_1_anim_sprite.html#aa35fc6cbfbd0f6e3e57a3117c8d5f986", null ],
    [ "currentFrame", "class_g_x_p_engine_1_1_anim_sprite.html#a0c171ac4934348b5e0895b8f955ccb27", null ],
    [ "frameCount", "class_g_x_p_engine_1_1_anim_sprite.html#a6b611b4384c43a1aeda59208fd12f281", null ],
    [ "height", "class_g_x_p_engine_1_1_anim_sprite.html#addc35977c543a14f8a48b9e836960bc8", null ],
    [ "width", "class_g_x_p_engine_1_1_anim_sprite.html#a2fdfe41938b338cf13030d179ecbcfdf", null ]
];