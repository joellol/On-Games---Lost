var class_g_x_p_engine_1_1_canvas =
[
    [ "Canvas", "class_g_x_p_engine_1_1_canvas.html#a6c126bf169eaa5b6edc4da9abf285dd4", null ],
    [ "Destroy", "class_g_x_p_engine_1_1_canvas.html#a41d5513cc8037d244c3bdd101f75bfc0", null ],
    [ "graphics", "class_g_x_p_engine_1_1_canvas.html#a6b7d825e2fd192094d0e1674c17844dd", null ]
];