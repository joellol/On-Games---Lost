var class_g_x_p_engine_1_1_game =
[
    [ "Game", "class_g_x_p_engine_1_1_game.html#a6d10f637740761e26fbe3668649b0680", null ],
    [ "Destroy", "class_g_x_p_engine_1_1_game.html#a4763f40c236725a591e07f7e0ebfd264", null ],
    [ "SetViewport", "class_g_x_p_engine_1_1_game.html#afecde817f37c96e76d26593c7fcac853", null ],
    [ "ShowMouse", "class_g_x_p_engine_1_1_game.html#a2f0f1eb7d0ba0c275deaef45421b8544", null ],
    [ "Start", "class_g_x_p_engine_1_1_game.html#a60cfaccee44dd4badd8629bcd9936beb", null ],
    [ "StepDelegate", "class_g_x_p_engine_1_1_game.html#a4d1f2cf034dc8d50480f94ea0da11fb4", null ],
    [ "height", "class_g_x_p_engine_1_1_game.html#a134c09653d9b6137a4762dc283a20883", null ],
    [ "width", "class_g_x_p_engine_1_1_game.html#a0a659aa4d59ed3729fc5d255651aac26", null ],
    [ "OnAfterStep", "class_g_x_p_engine_1_1_game.html#a21eda1f7129c978fa7f28cd502d7ae5f", null ],
    [ "OnBeforeStep", "class_g_x_p_engine_1_1_game.html#ae93f01e15a6ff137b4c2aba5449987e5", null ]
];