var class_g_x_p_engine_1_1_sprite =
[
    [ "Sprite", "class_g_x_p_engine_1_1_sprite.html#abeb17c5380c00ca3705b2442694ba4a1", null ],
    [ "Sprite", "class_g_x_p_engine_1_1_sprite.html#ab17521fb8104d21a9b609f8c70489317", null ],
    [ "createCollider", "class_g_x_p_engine_1_1_sprite.html#adbd7ebed1c5bc794e134ba914f37bfb6", null ],
    [ "GetExtents", "class_g_x_p_engine_1_1_sprite.html#a53815903035f9af8f3fbc0f5722c2a82", null ],
    [ "Mirror", "class_g_x_p_engine_1_1_sprite.html#a5ff2021646a5856160057e33bfa0662e", null ],
    [ "SetColor", "class_g_x_p_engine_1_1_sprite.html#a1273156710bcf4143a80147a721a696d", null ],
    [ "SetOrigin", "class_g_x_p_engine_1_1_sprite.html#a7f23dfc233b1a22c92ca548a5a6e7efc", null ],
    [ "alpha", "class_g_x_p_engine_1_1_sprite.html#a780d1b1a516887c7708188add3b23b2f", null ],
    [ "color", "class_g_x_p_engine_1_1_sprite.html#a6cf62404b2bca9e8eedcff197e8e594c", null ],
    [ "height", "class_g_x_p_engine_1_1_sprite.html#a05746222e444c0ba1eb8992e92ea99df", null ],
    [ "texture", "class_g_x_p_engine_1_1_sprite.html#a48c7dbc7d4d7903e23e23ee42f934df6", null ],
    [ "width", "class_g_x_p_engine_1_1_sprite.html#a6c1766de4d8d0b00dae6cadd5b577973", null ]
];