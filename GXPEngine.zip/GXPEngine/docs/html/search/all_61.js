var searchData=
[
  ['abs',['Abs',['../class_g_x_p_engine_1_1_mathf.html#a927e38496113f9c7cb944bd31bc55eba',1,'GXPEngine.Mathf.Abs(int value)'],['../class_g_x_p_engine_1_1_mathf.html#a16821b1f98a8841a1f63d064747d2e0e',1,'GXPEngine.Mathf.Abs(float value)']]],
  ['acos',['Acos',['../class_g_x_p_engine_1_1_mathf.html#a2acd56a0a3cbe6dff0bf3a58c1fb3057',1,'GXPEngine::Mathf']]],
  ['addchild',['AddChild',['../class_g_x_p_engine_1_1_game_object.html#ad213f53039f4a78d03e1e81d1b00ed55',1,'GXPEngine::GameObject']]],
  ['addchildat',['AddChildAt',['../class_g_x_p_engine_1_1_game_object.html#a407f9f417afaef615fba9852c7c4121d',1,'GXPEngine::GameObject']]],
  ['alpha',['alpha',['../class_g_x_p_engine_1_1_sprite.html#a780d1b1a516887c7708188add3b23b2f',1,'GXPEngine::Sprite']]],
  ['animationsprite',['AnimationSprite',['../class_g_x_p_engine_1_1_animation_sprite.html#a7aae689ba51de47b88048c56c655bf16',1,'GXPEngine.AnimationSprite.AnimationSprite(string filename, int cols, int rows, int frames=-1)'],['../class_g_x_p_engine_1_1_animation_sprite.html#adb45dabf078ed4b54fe4114dd3310e70',1,'GXPEngine.AnimationSprite.AnimationSprite(System.Drawing.Bitmap bitmap, int cols, int rows, int frames=-1)']]],
  ['animationsprite',['AnimationSprite',['../class_g_x_p_engine_1_1_animation_sprite.html',1,'GXPEngine']]],
  ['atan',['Atan',['../class_g_x_p_engine_1_1_mathf.html#a29905355e007aac271f3db4b19adcc89',1,'GXPEngine::Mathf']]],
  ['atan2',['Atan2',['../class_g_x_p_engine_1_1_mathf.html#a25f9b431290df6d6546a10b109bbb926',1,'GXPEngine::Mathf']]]
];
