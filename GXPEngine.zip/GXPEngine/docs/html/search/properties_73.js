var searchData=
[
  ['scalex',['scaleX',['../class_g_x_p_engine_1_1_transformable.html#ae8467a6cf97a80d429641a3565846347',1,'GXPEngine::Transformable']]],
  ['scaley',['scaleY',['../class_g_x_p_engine_1_1_transformable.html#a9eca26b4d2a05a84bf058514178ac7b1',1,'GXPEngine::Transformable']]]
];
